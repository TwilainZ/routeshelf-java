package dev.gdirect.lite;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.URL;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLSocketFactory;

/** Public Google Drive HTTP requests only; normal HTTPS certificate validation stays enabled. */
final class DirectNet {
    private DirectNet() {}

    static final class Probe {
        final URL finalUrl;
        final long size;
        final boolean ranges;
        final String filename;
        Probe(URL url, long size, boolean ranges, String filename) {
            this.finalUrl = url; this.size = size; this.ranges = ranges; this.filename = filename;
        }
    }

    static final class ScanResult {
        final String ip;
        final long millis;
        ScanResult(String ip, long millis) { this.ip = ip; this.millis = millis; }
        @Override public String toString() { return ip + "  ·  " + millis + " ms"; }
    }

    static String parseIp(String raw) {
        String s = raw == null ? "" : raw.trim();
        if (s.isEmpty()) return null;
        if (!s.matches("[0-9]{1,3}(\\.[0-9]{1,3}){3}"))
            throw new IllegalArgumentException("目前仅支持输入 IPv4 地址");
        for (String seg : s.split("\\.")) {
            if (Integer.parseInt(seg) > 255) throw new IllegalArgumentException("IP 地址无效");
        }
        return s;
    }

    static boolean googleHost(String host) {
        if (host == null) return false;
        String h = host.toLowerCase(Locale.ROOT);
        return h.equals("drive.google.com") || h.equals("drive.usercontent.google.com")
            || h.equals("www.googleapis.com") || h.equals("content.googleapis.com")
            || h.equals("drive.googleapis.com") || h.endsWith(".googleusercontent.com");
    }

    static URL normalizeSharedLink(String input) throws IOException {
        String raw = input == null ? "" : input.trim();
        if (raw.isEmpty()) throw new IOException("请先粘贴公开的 Google Drive 文件链接");
        URL url = new URL(raw);
        if (!url.getProtocol().equalsIgnoreCase("https") || !googleHost(url.getHost())
            || (url.getPort() != -1 && url.getPort() != 443)) {
            throw new IOException("仅接受 HTTPS Google Drive 文件链接");
        }
        String path = url.getPath();
        Matcher m = Pattern.compile("(?:/file/d/|/d/)([a-zA-Z0-9_-]{10,})").matcher(path);
        String id = m.find() ? m.group(1) : null;
        if (id == null) {
            m = Pattern.compile("(?:^|&)id=([a-zA-Z0-9_-]{10,})(?:&|$)")
                .matcher(url.getQuery() == null ? "" : url.getQuery());
            if (m.find()) id = m.group(1);
        }
        if (id == null && url.getHost().equalsIgnoreCase("drive.usercontent.google.com")
                && url.getPath().contains("download")) return url;
        if (id == null) throw new IOException("无法识别文件 ID；目前不支持文件夹及 Google 文档链接");
        return new URL("https://drive.usercontent.google.com/download?id=" + id
            + "&export=download&confirm=t");
    }

    static HttpsURLConnection open(URL url, String ip, String range) throws IOException {
        for (int redirects = 0; redirects < 8; redirects++) {
            if (!"https".equalsIgnoreCase(url.getProtocol()) || !googleHost(url.getHost())
                    || (url.getPort() != -1 && url.getPort() != 443)) {
                throw new IOException("服务器跳转到了不允许的地址，已停止下载");
            }
            HttpsURLConnection connection = (HttpsURLConnection) (ip == null
                ? url.openConnection() : url.openConnection(java.net.Proxy.NO_PROXY));
            connection.setInstanceFollowRedirects(false);
            connection.setConnectTimeout(9000);
            connection.setReadTimeout(20000);
            connection.setRequestProperty("User-Agent", "GDirectLite/0.1 Android");
            connection.setRequestProperty("Accept-Encoding", "identity");
            connection.setRequestProperty("Connection", "close");
            if (range != null) connection.setRequestProperty("Range", range);
            if (ip != null) {
                connection.setSSLSocketFactory(new DirectSocketFactory(
                    (SSLSocketFactory) SSLSocketFactory.getDefault(), ip));
            }
            int code = connection.getResponseCode();
            if (code == 301 || code == 302 || code == 303 || code == 307 || code == 308) {
                String location = connection.getHeaderField("Location");
                connection.disconnect();
                if (location == null) throw new IOException("Google 返回了无目标地址的跳转");
                url = new URL(url, location);
            } else {
                return connection;
            }
        }
        throw new IOException("跳转次数过多");
    }

    static Probe probe(URL start, String ip) throws IOException {
        URL url = start;
        for (int attempt = 0; attempt < 3; attempt++) {
            HttpsURLConnection connection = open(url, ip, "bytes=0-0");
            try {
                int code = connection.getResponseCode();
                if (code != 200 && code != 206) {
                    throw new IOException("Google Drive 返回 HTTP " + code + "；请确认文件公开可访问");
                }
                URL actual = connection.getURL();
                String disposition = connection.getHeaderField("Content-Disposition");
                String contentType = connection.getContentType();
                if (code == 200 && (contentType != null && contentType.toLowerCase(Locale.ROOT).contains("text/html"))
                    && (disposition == null || !disposition.toLowerCase(Locale.ROOT).contains("attachment"))) {
                    String page = readLimited(connection.getInputStream(), 48000);
                    URL confirmation = confirmationPage(actual, page);
                    if (confirmation == null) {
                        throw new IOException("Google 返回确认/登录网页；请检查共享权限或下载限额");
                    }
                    url = confirmation;
                    continue;
                }
                long size = connection.getContentLengthLong();
                boolean range = code == 206;
                if (range) {
                    String r = connection.getHeaderField("Content-Range");
                    Matcher match = Pattern.compile("bytes\\s+0-0/(\\d+)", Pattern.CASE_INSENSITIVE)
                        .matcher(r == null ? "" : r);
                    if (!match.find()) throw new IOException("服务器没有返回有效的文件大小");
                    size = Long.parseLong(match.group(1));
                }
                String name = getFilename(disposition, start);
                return new Probe(actual, size, range && size > 0, name);
            } finally { connection.disconnect(); }
        }
        throw new IOException("Google 下载确认页面重复出现");
    }

    private static String readLimited(InputStream in, int limit) throws IOException {
        try (InputStream stream = in; ByteArrayOutputStream b = new ByteArrayOutputStream()) {
            byte[] bytes = new byte[2048];
            int n;
            while (b.size() < limit && (n = stream.read(bytes, 0, Math.min(bytes.length, limit-b.size()))) != -1)
                b.write(bytes, 0, n);
            return b.toString(StandardCharsets.UTF_8.name());
        }
    }

    private static String attr(String tag, String name) {
        Matcher m = Pattern.compile("(?i)\\b" + Pattern.quote(name)
            + "\\s*=\\s*([\"'])(.*?)\\1").matcher(tag);
        if (m.find()) return m.group(2).replace("&amp;", "&");
        m = Pattern.compile("(?i)\\b" + Pattern.quote(name) + "\\s*=\\s*([^\\s>]+)").matcher(tag);
        return m.find() ? m.group(1) : null;
    }

    private static URL confirmationPage(URL base, String html) throws IOException {
        Matcher form = Pattern.compile("(?is)<form\\b([^>]*)>(.*?)</form>").matcher(html);
        while (form.find()) {
            String tag = form.group(1);
            if (!(tag.contains("download-form") || form.group(2).contains("confirm"))) continue;
            String action = attr(tag, "action");
            if (action == null) continue;
            StringBuilder extra = new StringBuilder();
            Matcher inputs = Pattern.compile("(?is)<input\\b[^>]*>").matcher(form.group(2));
            while (inputs.find()) {
                String key = attr(inputs.group(), "name");
                String value = attr(inputs.group(), "value");
                if (key != null && value != null) {
                    extra.append(extra.length() == 0 ? "" : "&")
                        .append(URLEncoder.encode(key, "UTF-8")).append("=")
                        .append(URLEncoder.encode(value, "UTF-8"));
                }
            }
            URL dest = new URL(base, action);
            return new URL(dest.toExternalForm() + (extra.length() == 0 ? "" :
                (dest.getQuery() == null ? "?" : "&") + extra));
        }
        return null;
    }

    private static String getFilename(String disposition, URL url) {
        String name = null;
        if (disposition != null) {
            Matcher m = Pattern.compile("(?i)filename\\*\\s*=\\s*UTF-8''([^;]+)").matcher(disposition);
            if (m.find()) {
                try { name = URLDecoder.decode(m.group(1), "UTF-8"); } catch (Exception ignored) {}
            }
            if (name == null) {
                m = Pattern.compile("(?i)filename\\s*=\\s*[\"]?([^\";]+)").matcher(disposition);
                if (m.find()) name = m.group(1);
            }
        }
        if (name == null || name.trim().isEmpty()) {
            Matcher m = Pattern.compile("(?:^|&)id=([a-zA-Z0-9_-]+)").matcher(url.getQuery() == null ? "" : url.getQuery());
            name = m.find() ? "gdrive-" + m.group(1) + ".bin" : "gdrive-download.bin";
        }
        name = name.replaceAll("[/\\\\\\p{Cntrl}]", "_").trim();
        if (name.length() > 150) name = name.substring(0, 150);
        return name.isEmpty() || name.equals(".") || name.equals("..") ? "gdrive-download.bin" : name;
    }

    static List<ScanResult> scan() throws IOException {
        LinkedHashSet<String> candidates = new LinkedHashSet<>();
        candidates.add("183.56.143.147"); // An untrusted candidate: HTTPS is ALWAYS checked.
        for (String host : new String[]{"www.googleapis.com", "drive.usercontent.google.com", "drive.google.com"}) {
            try {
                for (InetAddress a : InetAddress.getAllByName(host)) {
                    if (a.getAddress().length == 4 && !a.isLoopbackAddress() && !a.isSiteLocalAddress()) {
                        byte[] b = a.getAddress();
                        // Avoid Clash/Mihomo fake-IP networks (198.18.0.0/15).
                        if ((b[0] & 255) == 198 && ((b[1] & 255) == 18 || (b[1] & 255) == 19)) continue;
                        candidates.add(a.getHostAddress());
                    }
                }
            } catch (Exception ignored) { /* DNS may be blocked */ }
        }
        List<ScanResult> good = new ArrayList<>();
        for (String candidate : candidates) {
            if (good.size() >= 6) break;
            try {
                long start = System.nanoTime();
                HttpsURLConnection c = open(new URL("https://www.googleapis.com/drive/v3/about?fields=user"), candidate, null);
                try {
                    if (c.getResponseCode() == HttpURLConnection.HTTP_UNAUTHORIZED) {
                        good.add(new ScanResult(candidate, (System.nanoTime() - start)/1_000_000));
                    }
                } finally { c.disconnect(); }
            } catch (Exception ignored) { /* Certificate/network failure: discard candidate. */ }
        }
        good.sort(Comparator.comparingLong(r -> r.millis));
        return good;
    }

    static final class DirectSocketFactory extends SSLSocketFactory {
        private final SSLSocketFactory delegate;
        private final String ip;
        DirectSocketFactory(SSLSocketFactory delegate, String ip) { this.delegate = delegate; this.ip = ip; }
        @Override public String[] getDefaultCipherSuites() { return delegate.getDefaultCipherSuites(); }
        @Override public String[] getSupportedCipherSuites() { return delegate.getSupportedCipherSuites(); }
        private Socket connect(String host, int port, InetAddress local, int localPort) throws IOException {
            Socket raw = new Socket();
            if (local != null) raw.bind(new InetSocketAddress(local, localPort));
            raw.connect(new InetSocketAddress(InetAddress.getByName(ip), port), 8000);
            return delegate.createSocket(raw, host, port, true);
        }
        @Override public Socket createSocket(Socket existing, String host, int port, boolean autoClose) throws IOException {
            if (autoClose && existing != null) existing.close();
            return connect(host, port, null, 0);
        }
        @Override public Socket createSocket(String host, int port) throws IOException {
            return connect(host, port, null, 0);
        }
        @Override public Socket createSocket(String host, int port, InetAddress local, int localPort) throws IOException {
            return connect(host, port, local, localPort);
        }
        @Override public Socket createSocket(InetAddress host, int port) throws IOException {
            return connect(host.getHostAddress(), port, null, 0);
        }
        @Override public Socket createSocket(InetAddress host, int port, InetAddress local, int localPort) throws IOException {
            return connect(host.getHostAddress(), port, local, localPort);
        }
    }
}
