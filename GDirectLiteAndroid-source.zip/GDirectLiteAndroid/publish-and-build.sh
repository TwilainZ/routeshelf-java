#!/usr/bin/env bash
# Run inside the extracted GDirectLiteAndroid folder on a computer that has git and gh.
set -euo pipefail
if ! command -v git >/dev/null 2>&1; then echo 'Please install git.' >&2; exit 1; fi
if ! command -v gh >/dev/null 2>&1; then echo 'Please install GitHub CLI (gh).' >&2; exit 1; fi
if ! gh auth status >/dev/null 2>&1; then
  echo 'Run: gh auth login (in a separate command), then rerun this script.' >&2
  exit 1
fi
if [ ! -f 'app/build.gradle' ] || [ ! -f '.github/workflows/build-apk.yml' ]; then
  echo 'Run this script from the GDirectLiteAndroid project directory.' >&2
  exit 1
fi
if [ -e .git ]; then
  echo 'A git repository already exists here. Refusing to modify it automatically.' >&2
  exit 1
fi
NAME="${1:-gdirect-lite-android}"
if ! [[ "$NAME" =~ ^[a-zA-Z0-9._-]+$ ]]; then
  echo 'Invalid GitHub repository name.' >&2
  exit 1
fi
# Commit locally, then create a NEW PRIVATE repository. Never reuse other projects.
git init -b main
git add .
git -c user.name="${GH_USER:-GDirect Lite}" -c user.email="${GH_EMAIL:-gdirect-lite@users.noreply.github.com}" commit -m 'Initial Android prototype and APK build workflow'
gh repo create "$NAME" --private --source=. --remote=origin --push
URL="$(gh repo view --json url --jq .url)"
printf '\nSource pushed: %s\nBuilds are under: %s/actions\n' "$URL" "$URL"
printf 'After the build finishes, open the run and download the GDirectLite-debug-APK artifact.\n'
